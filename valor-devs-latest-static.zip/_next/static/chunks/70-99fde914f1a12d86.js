"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[70],{8030:function(e,t,n){n.d(t,{Z:function(){return l}});var r=n(2265);/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),i=function(){for(var e=arguments.length,t=Array(e),n=0;n<e;n++)t[n]=arguments[n];return t.filter((e,t,n)=>!!e&&n.indexOf(e)===t).join(" ")};/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var c={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,r.forwardRef)((e,t)=>{let{color:n="currentColor",size:a=24,strokeWidth:o=2,absoluteStrokeWidth:l,className:u="",children:h,iconNode:s,...d}=e;return(0,r.createElement)("svg",{ref:t,...c,width:a,height:a,stroke:n,strokeWidth:l?24*Number(o)/Number(a):o,className:i("lucide",u),...d},[...s.map(e=>{let[t,n]=e;return(0,r.createElement)(t,n)}),...Array.isArray(h)?h:[h]])}),l=(e,t)=>{let n=(0,r.forwardRef)((n,c)=>{let{className:l,...u}=n;return(0,r.createElement)(o,{ref:c,iconNode:t,className:i("lucide-".concat(a(e)),l),...u})});return n.displayName="".concat(e),n}},8954:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]])},462:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("BrainCircuit",[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M9 13a4.5 4.5 0 0 0 3-4",key:"10igwf"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M12 13h4",key:"1ku699"}],["path",{d:"M12 18h6a2 2 0 0 1 2 2v1",key:"105ag5"}],["path",{d:"M12 8h8",key:"1lhi5i"}],["path",{d:"M16 8V5a2 2 0 0 1 2-2",key:"u6izg6"}],["circle",{cx:"16",cy:"13",r:".5",key:"ry7gng"}],["circle",{cx:"18",cy:"3",r:".5",key:"1aiba7"}],["circle",{cx:"20",cy:"21",r:".5",key:"yhc1fs"}],["circle",{cx:"20",cy:"8",r:".5",key:"1e43v0"}]])},993:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Cloud",[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",key:"p7xjir"}]])},7419:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},690:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]])},5690:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("PenTool",[["path",{d:"M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z",key:"nt11vn"}],["path",{d:"m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18",key:"15qc1e"}],["path",{d:"m2.3 2.3 7.286 7.286",key:"1wuzzi"}],["circle",{cx:"11",cy:"11",r:"2",key:"xmgehs"}]])},2757:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Rocket",[["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}],["path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}],["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}]])},6141:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]])},8400:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Smartphone",[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]])},1240:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.417.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},4446:function(e,t,n){n.d(t,{M:function(){return m}});var r=n(7437),a=n(2265),i=n(5050),c=n(458),o=n(7797),l=n(9791);class u extends a.Component{getSnapshotBeforeUpdate(e){let t=this.props.childRef.current;if(t&&e.isPresent&&!this.props.isPresent){let e=this.props.sizeRef.current;e.height=t.offsetHeight||0,e.width=t.offsetWidth||0,e.top=t.offsetTop,e.left=t.offsetLeft}return null}componentDidUpdate(){}render(){return this.props.children}}function h(e){let{children:t,isPresent:n}=e,i=(0,a.useId)(),c=(0,a.useRef)(null),o=(0,a.useRef)({width:0,height:0,top:0,left:0}),{nonce:h}=(0,a.useContext)(l._);return(0,a.useInsertionEffect)(()=>{let{width:e,height:t,top:r,left:a}=o.current;if(n||!c.current||!e||!t)return;c.current.dataset.motionPopId=i;let l=document.createElement("style");return h&&(l.nonce=h),document.head.appendChild(l),l.sheet&&l.sheet.insertRule('\n          [data-motion-pop-id="'.concat(i,'"] {\n            position: absolute !important;\n            width: ').concat(e,"px !important;\n            height: ").concat(t,"px !important;\n            top: ").concat(r,"px !important;\n            left: ").concat(a,"px !important;\n          }\n        ")),()=>{document.head.removeChild(l)}},[n]),(0,r.jsx)(u,{isPresent:n,childRef:c,sizeRef:o,children:a.cloneElement(t,{ref:c})})}let s=e=>{let{children:t,initial:n,isPresent:i,onExitComplete:l,custom:u,presenceAffectsLayout:s,mode:p}=e,f=(0,c.h)(d),y=(0,a.useId)(),k=(0,a.useCallback)(e=>{for(let t of(f.set(e,!0),f.values()))if(!t)return;l&&l()},[f,l]),m=(0,a.useMemo)(()=>({id:y,initial:n,isPresent:i,custom:u,onExitComplete:k,register:e=>(f.set(e,!1),()=>f.delete(e))}),s?[Math.random(),k]:[i,k]);return(0,a.useMemo)(()=>{f.forEach((e,t)=>f.set(t,!1))},[i]),a.useEffect(()=>{i||f.size||!l||l()},[i]),"popLayout"===p&&(t=(0,r.jsx)(h,{isPresent:i,children:t})),(0,r.jsx)(o.O.Provider,{value:m,children:t})};function d(){return new Map}var p=n(3241);let f=e=>e.key||"";function y(e){let t=[];return a.Children.forEach(e,e=>{(0,a.isValidElement)(e)&&t.push(e)}),t}var k=n(9033);let m=e=>{let{children:t,custom:n,initial:o=!0,onExitComplete:l,presenceAffectsLayout:u=!0,mode:h="sync",propagate:d=!1}=e,[m,x]=(0,p.oO)(d),M=(0,a.useMemo)(()=>y(t),[t]),g=d&&!m?[]:M.map(f),v=(0,a.useRef)(!0),Z=(0,a.useRef)(M),w=(0,c.h)(()=>new Map),[C,z]=(0,a.useState)(M),[E,j]=(0,a.useState)(M);(0,k.L)(()=>{v.current=!1,Z.current=M;for(let e=0;e<E.length;e++){let t=f(E[e]);g.includes(t)?w.delete(t):!0!==w.get(t)&&w.set(t,!1)}},[E,g.length,g.join("-")]);let R=[];if(M!==C){let e=[...M];for(let t=0;t<E.length;t++){let n=E[t],r=f(n);g.includes(r)||(e.splice(t,0,n),R.push(n))}"wait"===h&&R.length&&(e=R),j(y(e)),z(M);return}let{forceRender:b}=(0,a.useContext)(i.p);return(0,r.jsx)(r.Fragment,{children:E.map(e=>{let t=f(e),a=(!d||!!m)&&(M===E||g.includes(t));return(0,r.jsx)(s,{isPresent:a,initial:(!v.current||!!o)&&void 0,custom:a?void 0:n,presenceAffectsLayout:u,mode:h,onExitComplete:a?void 0:()=>{if(!w.has(t))return;w.set(t,!0);let e=!0;w.forEach(t=>{t||(e=!1)}),e&&(null==b||b(),j(Z.current),d&&(null==x||x()),l&&l())},children:e},t)})})}}}]);